//import { Request, Response,NextFunction } from "express";


//export function isAuthenticated(
  //  req: Request,
    //res: Response,
    //next: NextFunction



   // )
//{
 //   console.log("Executou o middleware isAuthenticated")
//}
//armazena o token enviado na requisição explicação
//const authToken = req.headers.authorization;

//verifica se o usuário enviou um token na requisição explicação

//if(!authToken)
//{
  //  return res.status(401).end();
//}
  //  console.log(authToken);

//{

//}
